import { RouterModule , Router } from '@angular/router';
import { LoginService } from '../login.service';
import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
  providers: [LoginService]
})
export class LoginComponent implements OnInit {

  constructor(private service: LoginService , private routes: Router) { }
msg;
  ngOnInit(): any {
  }
  check(uname: string, p: string): any {
    const output = this.service.checkusernameandpassword(uname, p);
    if (output === true) {
      this.routes.navigate(['/']);
    } else {
      this.msg = 'Invalid username or password';
    }
  }
}
