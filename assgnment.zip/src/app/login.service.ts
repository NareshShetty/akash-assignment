import { Injectable } from '@angular/core';

@Injectable()
export class LoginService {

  constructor() { }
  checkusernameandpassword(uname: string, pwd: string): any {
    if (uname === 'admin' && pwd === '@P9zkUP=') {
      localStorage.setItem('tcs_user', uname);
      localStorage.setItem('tcs_pass', pwd);
      return true;
    } else {
      return false;
    }
  }
}
